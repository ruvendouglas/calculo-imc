import 'package:flutter/material.dart';

void main() {
  runApp(IMCCalculator());
}

class IMCCalculator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculadora de IMC',
      home: IMCCalculatorHome(),
    );
  }
}

class IMCCalculatorHome extends StatefulWidget {
  @override
  _IMCCalculatorHomeState createState() => _IMCCalculatorHomeState();
}

class _IMCCalculatorHomeState extends State<IMCCalculatorHome> {
  final TextEditingController weightController = TextEditingController();
  final TextEditingController heightController = TextEditingController();
  String result = '';

  void calculateIMC() {
    double weight = double.tryParse(weightController.text) ?? 0;
    double height = double.tryParse(heightController.text) ?? 0;

    if (weight > 0 && height > 0) {
      double imc = weight / (height * height);
      setState(() {
        result = 'Seu IMC é: ${imc.toStringAsFixed(2)}\n' + classifyIMC(imc);
      });
    }
  }

  String classifyIMC(double imc) {
    if (imc < 18.5)
      return 'Classificação: Abaixo do peso';
    else if (imc < 24.9)
      return 'Classificação: Peso normal';
    else if (imc < 29.9)
      return 'Classificação: Sobrepeso';
    else
      return 'Classificação: Obesidade';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculadora de IMC'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: weightController,
              decoration: InputDecoration(labelText: 'Peso (kg)'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: heightController,
              decoration: InputDecoration(labelText: 'Altura (m)'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: calculateIMC,
              child: Text('Calcular IMC'),
            ),
            SizedBox(height: 20),
            Text(
              result,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}
